package ru.kolonka.control

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.sin

private val Back = Color(0xFF050B08)
private val SurfaceA = Color(0xFF0C1711)
private val SurfaceB = Color(0xFF102219)
private val Green = Color(0xFF48F28D)
private val Mint = Color(0xFFB3FFD0)
private val Secondary = Color(0xFF91A99A)
private val White = Color(0xFFF2FFF6)

class MainActivity : ComponentActivity() {
    private var virtualizer: Virtualizer? = null
    private var bassBoost: BassBoost? = null
    private var equalizer: Equalizer? = null
    private var hasVirtualizer = false
    private var hasBass = false
    private var hasEqualizer = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(5, 11, 8)
        window.navigationBarColor = android.graphics.Color.rgb(5, 11, 8)
        try { virtualizer = Virtualizer(0, 0); hasVirtualizer = virtualizer?.hasControl() == true } catch (_: Exception) {}
        try { bassBoost = BassBoost(0, 0); hasBass = bassBoost?.hasControl() == true } catch (_: Exception) {}
        try { equalizer = Equalizer(0, 0); hasEqualizer = equalizer?.hasControl() == true } catch (_: Exception) {}
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = Back, surface = SurfaceA, primary = Green,
                    onPrimary = Back, onBackground = White, onSurface = White,
                    secondary = Mint
                )
            ) {
                KolonkaApp(
                    hasVirtualizer, hasBass, hasEqualizer,
                    onSpatial = { enabled, strength ->
                        try {
                            virtualizer?.enabled = enabled && hasVirtualizer
                            if (hasVirtualizer) virtualizer?.setStrength((strength * 10).toShort())
                        } catch (_: Exception) {}
                    },
                    onBass = { enabled, strength ->
                        try {
                            bassBoost?.enabled = enabled && hasBass
                            if (hasBass) bassBoost?.setStrength((strength * 10).toShort())
                        } catch (_: Exception) {}
                    },
                    onEq = { band, level ->
                        try { equalizer?.setBandLevel(band.toShort(), level.toShort()) } catch (_: Exception) {}
                    },
                    eqRange = try { equalizer?.bandLevelRange?.let { it[0].toInt()..it[1].toInt() } ?: (-1500..1500) } catch (_: Exception) { -1500..1500 },
                    eqBands = try { equalizer?.numberOfBands?.toInt() ?: 0 } catch (_: Exception) { 0 }
                )
            }
        }
    }

    override fun onDestroy() {
        try { virtualizer?.release() } catch (_: Exception) {}
        try { bassBoost?.release() } catch (_: Exception) {}
        try { equalizer?.release() } catch (_: Exception) {}
        super.onDestroy()
    }
}

private enum class Page { HOME, SPATIAL, EQUALIZER, BASS, VOICE }

@Composable
private fun KolonkaApp(
    hasVirtualizer: Boolean,
    hasBass: Boolean,
    hasEqualizer: Boolean,
    onSpatial: (Boolean, Int) -> Unit,
    onBass: (Boolean, Int) -> Unit,
    onEq: (Int, Int) -> Unit,
    eqRange: IntRange,
    eqBands: Int
) {
    var page by remember { mutableStateOf(Page.HOME) }
    var spatialOn by remember { mutableStateOf(false) }
    var spatialLevel by remember { mutableFloatStateOf(70f) }
    var bassOn by remember { mutableStateOf(false) }
    var bassLevel by remember { mutableFloatStateOf(45f) }
    var voiceOn by remember { mutableStateOf(false) }
    var volume by remember { mutableFloatStateOf(68f) }
    var eqOn by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF08130D), Back, Color(0xFF030705))))) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 30.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("КОЛОНКА", color = Secondary, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Контроль", color = White, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
                            Spacer(Modifier.width(7.dp))
                            Box(Modifier.size(7.dp).background(Green, CircleShape))
                        }
                    }
                    Icon(Icons.Rounded.Settings, null, tint = Secondary, modifier = Modifier.size(25.dp))
                }
            }
            item { SpeakerHero() }
            item {
                GlassCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("ГРОМКОСТЬ", color = Secondary, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                            Text("${volume.toInt()}%", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        }
                        Icon(Icons.Rounded.VolumeUp, null, tint = Green, modifier = Modifier.size(27.dp))
                    }
                    Slider(value = volume, onValueChange = { volume = it }, valueRange = 0f..100f, colors = sliderColors())
                    Text("Демонстрационный регулятор · не управляет колонкой", color = Secondary, fontSize = 11.sp)
                }
            }
            item {
                GlassCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("ПРОСТРАНСТВЕННОЕ ЗВУЧАНИЕ", color = Green, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                            Spacer(Modifier.height(5.dp))
                            Text("Ощущение объёма со всех сторон", color = White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Switch(checked = spatialOn, onCheckedChange = {
                            spatialOn = it; onSpatial(it, spatialLevel.toInt())
                        }, colors = SwitchDefaults.colors(checkedThumbColor = Back, checkedTrackColor = Green))
                    }
                    Spacer(Modifier.height(8.dp))
                    SpatialArtwork(spatialOn)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Интенсивность эффекта", color = White, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        Text("${spatialLevel.toInt()}%", color = Green, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(value = spatialLevel, onValueChange = {
                        spatialLevel = it; if (spatialOn) onSpatial(true, it.toInt())
                    }, valueRange = 0f..100f, colors = sliderColors())
                    Text(
                        if (hasVirtualizer) "Системный виртуализатор найден. Реальная обработка зависит от устройства и аудиомаршрута."
                        else "На этом устройстве системный 3D-виртуализатор недоступен.",
                        color = Secondary, fontSize = 11.sp, lineHeight = 15.sp
                    )
                    TextButton(onClick = { page = Page.SPATIAL }) {
                        Text("РАСШИРЕННЫЕ НАСТРОЙКИ", color = Green, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        Icon(Icons.Rounded.ArrowForward, null, tint = Green)
                    }
                }
            }
            item {
                Text("НАСТРОЙКИ ЗВУКА", color = Secondary, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FeatureTile("Эквалайзер", "Частоты", Icons.Rounded.Equalizer, Modifier.weight(1f)) { page = Page.EQUALIZER }
                    FeatureTile("Бас", "Низкие частоты", Icons.Rounded.GraphicEq, Modifier.weight(1f)) { page = Page.BASS }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FeatureTile("Голос", "Чёткость речи", Icons.Rounded.RecordVoiceOver, Modifier.weight(1f)) { page = Page.VOICE }
                    FeatureTile("3D-звук", "Объём", Icons.Rounded.SurroundSound, Modifier.weight(1f)) { page = Page.SPATIAL }
                }
            }
        }

        if (page != Page.HOME) {
            SettingsOverlay(
                page = page,
                onBack = { page = Page.HOME },
                spatialOn = spatialOn, onSpatialToggle = { spatialOn = it; onSpatial(it, spatialLevel.toInt()) },
                spatialLevel = spatialLevel, onSpatialLevel = { spatialLevel = it; if (spatialOn) onSpatial(true, it.toInt()) },
                hasVirtualizer = hasVirtualizer,
                bassOn = bassOn, onBassToggle = { bassOn = it; onBass(it, bassLevel.toInt()) },
                bassLevel = bassLevel, onBassLevel = { bassLevel = it; if (bassOn) onBass(true, it.toInt()) }, hasBass = hasBass,
                eqOn = eqOn, onEqToggle = { eqOn = it }, hasEqualizer = hasEqualizer,
                eqBands = eqBands, eqRange = eqRange, onEq = onEq,
                voiceOn = voiceOn, onVoice = { voiceOn = it }
            )
        }
    }
}

@Composable
private fun SpeakerHero() {
    GlassCard(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("ВАША АКУСТИКА", color = Secondary, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                Text("Яндекс Станция", color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Макс · зелёная", color = Green, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(7.dp).background(Color(0xFFFFC857), CircleShape))
                    Spacer(Modifier.width(6.dp))
                    Text("Не подключена", color = Secondary, fontSize = 11.sp)
                }
            }
            SpeakerDrawing(Modifier.width(132.dp).height(166.dp))
        }
    }
}

@Composable
private fun SpeakerDrawing(modifier: Modifier = Modifier) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Box(Modifier.size(128.dp).blur(28.dp).background(Green.copy(alpha = .17f), CircleShape))
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width; val h = size.height
            drawRoundRect(
                brush = Brush.horizontalGradient(listOf(Color(0xFF07512D), Color(0xFF23B86B), Color(0xFF064325))),
                topLeft = Offset(w * .17f, h * .08f), size = Size(w * .66f, h * .82f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * .25f, w * .25f)
            )
            for (y in 0..34) for (x in 0..24) {
                val px = w * (.22f + x * .023f)
                val py = h * (.13f + y * .021f)
                drawCircle(Color(0xFFB5FFD1).copy(alpha = .16f), radius = 1.05f, center = Offset(px, py))
            }
            drawCircle(Color(0xFFD7FFE5), radius = w * .105f, center = Offset(w * .5f, h * .47f), style = Stroke(width = 2.2f))
            drawCircle(Color(0xFFD7FFE5), radius = w * .045f, center = Offset(w * .5f, h * .47f))
            drawRoundRect(Color(0xFF06371F), Offset(w * .2f, h * .84f), Size(w * .6f, h * .055f), androidx.compose.ui.geometry.CornerRadius(8f))
        }
        Text("Я", color = Color.White.copy(alpha = .95f), fontSize = 30.sp, fontWeight = FontWeight.Black, modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 18.dp))
    }
}

@Composable
private fun SpatialArtwork(active: Boolean) {
    val alpha by animateFloatAsState(if (active) 1f else .45f, tween(500, easing = FastOutSlowInEasing), label = "spatial")
    Canvas(Modifier.fillMaxWidth().height(106.dp)) {
        val center = Offset(size.width / 2, size.height / 2)
        for (i in 0..3) {
            val rx = size.width * (.18f + i * .085f)
            val ry = size.height * (.18f + i * .13f)
            drawOval(
                color = Green.copy(alpha = alpha * (0.55f - i * .09f)),
                topLeft = Offset(center.x - rx, center.y - ry),
                size = Size(rx * 2, ry * 2),
                style = Stroke(width = 1.4.dp.toPx(), cap = StrokeCap.Round)
            )
        }
        for (i in 0..17) {
            val x = size.width * (i + 1) / 19f
            val y = center.y + sin(i * PI / 2.2).toFloat() * size.height * .18f
            drawCircle(Green.copy(alpha = alpha), 2.5.dp.toPx(), Offset(x, y))
        }
        drawCircle(Mint.copy(alpha = alpha), 4.dp.toPx(), center)
    }
}

@Composable
private fun GlassCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.fillMaxWidth()
            .clip(RoundedCornerShape(26.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF14291D), Color(0xFF0A1510))))
            .border(1.dp, Color(0xFF2A6946).copy(alpha = .65f), RoundedCornerShape(26.dp))
            .padding(17.dp),
        verticalArrangement = Arrangement.spacedBy(9.dp),
        content = content
    )
}

@Composable
private fun FeatureTile(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.height(112.dp).clip(RoundedCornerShape(21.dp))
            .background(SurfaceA).border(1.dp, Color(0xFF214B34), RoundedCornerShape(21.dp))
            .clickable(onClick = onClick).padding(14.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Icon(icon, null, tint = Green, modifier = Modifier.size(25.dp))
        Column {
            Text(title, color = White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Text(subtitle, color = Secondary, fontSize = 11.sp)
        }
    }
}

@Composable
private fun SettingsOverlay(
    page: Page, onBack: () -> Unit,
    spatialOn: Boolean, onSpatialToggle: (Boolean) -> Unit, spatialLevel: Float, onSpatialLevel: (Float) -> Unit, hasVirtualizer: Boolean,
    bassOn: Boolean, onBassToggle: (Boolean) -> Unit, bassLevel: Float, onBassLevel: (Float) -> Unit, hasBass: Boolean,
    eqOn: Boolean, onEqToggle: (Boolean) -> Unit, hasEqualizer: Boolean, eqBands: Int, eqRange: IntRange, onEq: (Int, Int) -> Unit,
    voiceOn: Boolean, onVoice: (Boolean) -> Unit
) {
    val title = when (page) {
        Page.SPATIAL -> "Пространственный звук"
        Page.EQUALIZER -> "Эквалайзер"
        Page.BASS -> "Бас"
        Page.VOICE -> "Улучшение голоса"
        else -> ""
    }
    Box(Modifier.fillMaxSize().background(Back)) {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, "Назад", tint = Green) }
                    Text(title, color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
            }
            when (page) {
                Page.SPATIAL -> {
                    item {
                        GlassCard {
                            SpatialArtwork(spatialOn)
                            SettingSwitch("Пространственный эффект", "Виртуализация средствами Android", spatialOn, onSpatialToggle)
                            Text("Интенсивность · ${spatialLevel.toInt()}%", color = Green, fontWeight = FontWeight.Bold)
                            Slider(spatialLevel, onSpatialLevel, colors = sliderColors())
                            CapabilityText(hasVirtualizer, "Виртуализатор Android доступен", "Виртуализатор Android не поддерживается устройством")
                        }
                    }
                    item { InfoCard("Важно", "Эффект может обрабатывать звук телефона. Он не управляет DSP Яндекс Станции и не гарантирует обработку музыки, которая воспроизводится самой колонкой.") }
                }
                Page.BASS -> item {
                    GlassCard {
                        SettingSwitch("Усиление баса", "Системный BassBoost Android", bassOn, onBassToggle)
                        Text("Интенсивность · ${bassLevel.toInt()}%", color = Green, fontWeight = FontWeight.Bold)
                        Slider(bassLevel, onBassLevel, colors = sliderColors())
                        CapabilityText(hasBass, "Системный эффект баса доступен", "Системный эффект баса недоступен на устройстве")
                    }
                }
                Page.EQUALIZER -> {
                    item { GlassCard { SettingSwitch("Эквалайзер", "Изменение частотных полос Android", eqOn, onEqToggle); CapabilityText(hasEqualizer, "Эквалайзер найден", "Эквалайзер не предоставлен прошивкой") } }
                    if (eqBands > 0) {
                        items(eqBands) { band ->
                            var level by remember(band) { mutableFloatStateOf(0f) }
                            GlassCard {
                                Text("Полоса ${band + 1}", color = White, fontWeight = FontWeight.SemiBold)
                                Slider(level, {
                                    level = it
                                    val value = (eqRange.first + (eqRange.last - eqRange.first) * it / 100f).toInt()
                                    if (eqOn) onEq(band, value)
                                }, valueRange = 0f..100f, colors = sliderColors())
                            }
                        }
                    }
                }
                Page.VOICE -> item {
                    GlassCard {
                        SettingSwitch("Улучшение голоса", "Режим интерфейса", voiceOn, onVoice)
                        InfoCard("Пока не реализовано", "Android не предоставляет универсальный системный эффект улучшения голоса для всех приложений. Переключатель пока сохраняет состояние интерфейса и не меняет звук.")
                    }
                }
                else -> Unit
            }
        }
    }
}

@Composable
private fun SettingSwitch(title: String, subtitle: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Text(subtitle, color = Secondary, fontSize = 11.sp)
        }
        Switch(checked, onChecked, colors = SwitchDefaults.colors(checkedThumbColor = Back, checkedTrackColor = Green))
    }
}

@Composable
private fun CapabilityText(available: Boolean, yes: String, no: String) {
    Text(if (available) "● $yes" else "● $no", color = if (available) Green else Color(0xFFFFC36A), fontSize = 12.sp)
}

@Composable
private fun InfoCard(title: String, body: String) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(SurfaceB).padding(15.dp)) {
        Text(title, color = Green, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(5.dp))
        Text(body, color = Secondary, fontSize = 12.sp, lineHeight = 17.sp)
    }
}

@Composable
private fun sliderColors() = SliderDefaults.colors(
    thumbColor = Green, activeTrackColor = Green, inactiveTrackColor = Color(0xFF294535),
    activeTickColor = Green, inactiveTickColor = Color(0xFF294535)
)
